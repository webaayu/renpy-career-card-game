# ========================
# Initialization & Styles
# ========================
define selected_career= ""
default selected_sector = ""
define healthcare_cards = []
define civil_services_cards = []
define education_cards = []
define all_career_cards = []
define user_name = ""
default user_gender = ""
define user = Character(name="user_name", dynamic = True)
default persistent.welcome_music_played = False
image score = "images/score.jpg"
image feedback = "images/feedback.jpg"

init python:

    import os, json, random
    def load_career_cards(sector):
        folder = os.path.join(config.basedir, "game", "careers", sector)
        cards = []
        if os.path.isdir(folder):
            for filename in os.listdir(folder):
                renpy.log("Found file: " + filename)
                if filename.endswith(".json"):
                    path = os.path.join(folder, filename)
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        cards.append(data)
                        renpy.log("Loaded card from: " + path)
                    except Exception as e:
                        renpy.log("Error loading {}: {}".format(path, e))
        else:
            renpy.log("Folder not found: " + folder)
        return cards

    healthcare_cards = load_career_cards("Healthcare")
    civil_services_cards = load_career_cards("CivilServices")
    education_cards = load_career_cards("Education")
    engineering_cards = load_career_cards("Engineering")
    all_career_cards = healthcare_cards + civil_services_cards + education_cards + engineering_cards

    def get_random_career():
        enabled = [card for card in all_career_cards if card["CareerCard"]["Enabled"] == 1]
        return random.choice(enabled)

# ========================
# Story Labels
# ========================
 
label start:
    scene black
    play music "audio/background_music.mp3" #loop
    call screen navigation_start
#    jump random_selection

label random_selection:
    play music "audio/background_music.mp3" #loop
    call screen job_selection_menu
    $ career = _return
    stop music
    jump careers_story

label careers_story:
    $ personal_growth = 20
    $ community_trust = 20

    scene expression career['CareerCard']['ImageMale']
    "Welcome on-duty [career['CareerCard']['Title']] {color=#ffa500}{b}[user]!{/b}{/color}"
    "{color=#FFD700}Overview:\n{color=#FFFFFF}{size=25}\"[career['CareerCard']['Overview']]\"{/color}{/size}"
    
    $ benefits_text = "\n".join([f"- {b}" for b in career['CareerCard']['Benefits and Challenges']['Benefits']])
    "{color=#00FF00}Benefits:\n{size=25}{color=#ffffff}[benefits_text]{/color}{/size}"
    
    $ challenges_text = "\n".join([f"- {c}" for c in career['CareerCard']['Benefits and Challenges']['Job Challenges']])
    "{color=#ff0000}Challenges:\n{size=25}{color=#ffffff}[challenges_text]{/color}{/size}"

# ✅ Show the heading text at the top of the screen
    window hide
    show screen highlighted_text("How Will You Step Into This Role, [user]???")
    play music "audio/step_into_role.mp3"
    $ renpy.pause(2.5)  # Pause before showing choices
    stop music
    menu:
        "{color=#00FFAA}Option A:{/color}\n{color=#ffffff}[career['CareerCard']['Choices'][0]['Option']]{/color}":
            $ personal_growth += career['CareerCard']['Choices'][0]['PersonalImpact']
            $ community_trust += career['CareerCard']['Choices'][0]['CommunityImpact']
            scene expression career['CareerCard']['ImageMale']
            "{color=#FFA500}[career['CareerCard']['Choices'][0]['Result']]{/color}"
        
        "{color=#00FFAA}Option B:{/color}\n{color=#ffffff}[career['CareerCard']['Choices'][1]['Option']]{/color}":
            $ personal_growth += career['CareerCard']['Choices'][1]['PersonalImpact']
            $ community_trust += career['CareerCard']['Choices'][1]['CommunityImpact']
            scene expression career['CareerCard']['ImageMale']
            "{color=#ffffff}[career['CareerCard']['Choices'][1]['Result']]{/color}"
    
    hide screen highlighted_text
    window show
    $ scenario_index = 0
    $ scenario_count = len(career['Scenarios'])
    
    "You stand at the crossroads of your destiny. {color=#ffff00}{b}Every choice you make will shape your journey!{/b}{/color} Are you ready to carve your path to success?"
    jump scenario_loop

label scenario_loop:
    if scenario_index >= scenario_count:
        jump game_end  

    window hide
    scene expression career['Scenarios'][scenario_index]['BackgroundImage']
    play music career['Scenarios'][scenario_index]['Audio'] 
    $ quest = scenario_index + 1
    show screen scenario_text("{color=#FFFF00}Quest [quest]:{/color}{color=#00FFAA} [career['Scenarios'][scenario_index]['Title']] {/color}\n{color=#FFFFFF}[career['Scenarios'][scenario_index]['Description']]{/color}")
    
    menu:  
        "{color=#00FFAA}Option A:{/color}\n{color=#ffffff}[career['Scenarios'][scenario_index]['DecisionCards'][0]['Option']]{/color}":
            $ personal_growth += career['Scenarios'][scenario_index]['DecisionCards'][0]['Outcomes']['PersonalImpact']
            $ community_trust += career['Scenarios'][scenario_index]['DecisionCards'][0]['Outcomes']['CommunityImpact']
            scene expression career['Scenarios'][scenario_index]['BackgroundImage']
            "{b}{color=#FFA500}[career['CareerCard']['Title']] [user], your decision is set in motion… let’s see what comes next.{/color}{/b}"

        "{color=#00FFAA}Option B:{/color}\n{color=#ffffff}[career['Scenarios'][scenario_index]['DecisionCards'][1]['Option']]{/color}":
            $ personal_growth += career['Scenarios'][scenario_index]['DecisionCards'][1]['Outcomes']['PersonalImpact']
            $ community_trust += career['Scenarios'][scenario_index]['DecisionCards'][1]['Outcomes']['CommunityImpact']
            scene expression career['Scenarios'][scenario_index]['BackgroundImage']
            "{b}{color=#FFA500}[career['CareerCard']['Title']] [user], You chose a different path... let's see where it leads.{/color}{/b}"

    hide screen scenario_text
    stop music
    $ scenario_index += 1  
    
    if scenario_index >= scenario_count:
        jump game_end  
    else:
        menu:
            "{color=#ffa500}\nSee Your Progress Up Till Now\n{/color}":
                jump game_end

            "{color=#00ff00}\nCarry on with New Quest\n{/color}":
                jump scenario_loop

            "{color=#ff0000}\nQuit\n{/color}":
                scene black
                call screen navigation

window show

label game_end:
    scene score
    
    $ total_scenarios = max(1, scenario_count)  # Ensure at least one scenario is considered
    $ secured_score = ((personal_growth + community_trust) / (total_scenarios * 40)) * 100  # Normalize to percentage
    
    if secured_score >= 70:
        scene expression career['Result']['AchievedImage']
        "{b}{color=#FFD700}[career['Result']['Achieved']]{/b}"
    elif secured_score >= 60:
        scene expression career['Result']['ModerateImage']
        "{b}{color=#FFD700}[career['Result']['Moderate']]{/b}"
    else:
        scene expression career['Result']['RetryImage']
        "{b}{color=#FF4500}[career['Result']['Retry']]{/b}"
    
    #scene expression career['Result']['QuitImage']
    #"{b}{color=#ff00ff}Game Over!{/b}"

    jump feedback
    
label feedback:
    scene feedback
    "Thank you for playing this Game! Please provide your feedback."
    scene black
    call screen feedback_screen
    return